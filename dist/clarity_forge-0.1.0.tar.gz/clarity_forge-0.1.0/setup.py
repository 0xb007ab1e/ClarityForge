# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['clarity_forge',
 'clarity_forge.api',
 'clarity_forge.api.v1',
 'clarity_forge.core']

package_data = \
{'': ['*']}

install_requires = \
['click>=8.2.1,<9.0.0',
 'fastapi>=0.115.14,<0.116.0',
 'pydantic>=2.11.7,<3.0.0',
 'uvicorn>=0.35.0,<0.36.0']

entry_points = \
{'console_scripts': ['clarity-forge = clarity_forge.cli:cli']}

setup_kwargs = {
    'name': 'clarity-forge',
    'version': '0.1.0',
    'description': '',
    'long_description': '# ClarityForge\n\nA project to build and refine AI-powered development guardrails.\n',
    'author': 'ClarityForge Team',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
